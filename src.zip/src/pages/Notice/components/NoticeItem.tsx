import { useEffect, useState } from 'react';
import { fetchPost } from '@/api/notice';
import { INotice, IPost } from '@carebell/bell-core';
import Post from './Post';
import Datetime from './Datetime';
import { StyledListItem, StyledLink } from './Notice.style';
import NoticeSkeletonItem from './NoticeSkeletonItem';

interface NoticeResponse {
  notice: INotice;
}

const NoticeItem = ({ notice }: NoticeResponse) => {
  const [post, setPost] = useState<IPost | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchPost(notice.postUuid)
      .then(setPost)
      .finally(() => setLoading(false));
  }, [notice.postUuid]);

  if (loading) {
    return <NoticeSkeletonItem />;
  }

  if (!post) {
    return null;
  }

  return (
    <StyledListItem>
      <StyledLink to={`/notice/${notice.id}`}>
        <Datetime datetime={notice.updatedAt ?? notice.createdAt} />
        <Post post={post} />
      </StyledLink>
    </StyledListItem>
  );
};

export default NoticeItem;
