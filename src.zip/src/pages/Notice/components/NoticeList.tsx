import { useEffect, useState } from 'react';
import { fetchNoticeList } from '@/api/notice';
import { INotice } from '@carebell/bell-core';
import NoticeItem from './NoticeItem';
import NoticeSkeletonItem from './NoticeSkeletonItem';

interface ListResponse {
  count: number;
  rows: INotice[];
}

const NoticeList = () => {
  const [noticeResponse, setNoticeResponse] = useState<ListResponse | null>(
    null,
  );
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchNoticeList()
      .then(setNoticeResponse)
      .finally(() => setLoading(false));
  }, []);

  if (loading) {
    return Array.from({ length: 5 }).map((_, index) => (
      <NoticeSkeletonItem key={index} />
    ));
  }

  return (
    <ul>
      {noticeResponse?.rows.map((notice) => (
        <NoticeItem
          key={notice.id}
          notice={{
            id: notice.id,
            postUuid: notice.postUuid,
            updatedAt: notice.updatedAt,
            createdAt: notice.createdAt,
            userUuid: notice.userUuid,
            uuid: notice.uuid,
            visibility: notice.visibility,
            deletedAt: notice.deletedAt,
          }}
        />
      ))}
    </ul>
  );
};

export default NoticeList;
